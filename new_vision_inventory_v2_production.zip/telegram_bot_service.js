/**
 * ============================================================================
 * NEW VISION SCHOOL INVENTORY - TELEGRAM BOT SERVICE (PRO V2.0)
 * ============================================================================
 * 
 * Bot ស្វ័យប្រវត្តិតាមដាន និងអនុម័តការដកសម្ភារៈសាលារៀន ញូវវីសិន (3-Tier Workflow):
 * 1. បុគ្គលិក (Staff): ជ្រើសរើសប្រភេទសម្ភារៈ, មុខសម្ភារៈ, ចំនួន, និងគោលបំណង -> ផ្ញើសំណើ
 * 2. អ្នកកាន់ស្តុក (Stock Keeper): ពិនិត្យស្តុកជាក់ស្តែង -> ចុចបញ្ជាក់ & បញ្ជូនបន្តទៅលោកនាយក
 * 3. នាយកសាលា (Director): ពិនិត្យ និងចុច «អនុម័ត (Approve)» ឬ «បដិសេធ (Reject)»
 * 4. ប្រព័ន្ធស្វ័យប្រវត្តិ: ផ្ញើសារដំណឹងទៅបុគ្គលិក និងអ្នកកាន់ស្តុកភ្លាមៗ!
 * 
 * ដំណើរការដោយមិនបាច់ដំឡើងកញ្ចប់ npm បន្ថែម (Built-in Node.js fetch)
 * ដំណើរការ: agy-node telegram_bot_service.js ឬ node telegram_bot_service.js
 * ============================================================================
 */

const fs = require('fs');
const path = require('path');
const http = require('http');

// 1. CONFIGURATION
const CONFIG_FILE = path.join(__dirname, 'telegram_bot_config.json');
const DATA_FILE = path.join(__dirname, 'telegram_requests.json');

let config = {
  botToken: process.env.TELEGRAM_BOT_TOKEN || '',
  directorChatId: process.env.TELEGRAM_DIRECTOR_CHAT_ID || '',
  stockKeeperChatId: process.env.TELEGRAM_STOCK_CHAT_ID || '',
  supabaseUrl: process.env.SUPABASE_URL || '',
  supabaseKey: process.env.SUPABASE_KEY || process.env.SUPABASE_SERVICE_ROLE_KEY || '',
  schoolName: 'សាលារៀន ញូវវីសិន (New Vision School)',
  pollIntervalMs: 1500
};

// Load custom config file if present
if (fs.existsSync(CONFIG_FILE)) {
  try {
    const loaded = JSON.parse(fs.readFileSync(CONFIG_FILE, 'utf8'));
    config = { ...config, ...loaded };
  } catch (e) {
    console.warn('Could not parse telegram_bot_config.json, using defaults.');
  }
}

// Default Catalog Categories & Materials
const CATALOG = {
  'ឧបករណ៍បច្ចេកវិទ្យា & IT': [
    { id: 'NV-IT-001', name: 'កុំព្យូទ័រយួរដៃ Dell Latitude 3420', unit: 'គ្រឿង', stock: 35 },
    { id: 'NV-IT-002', name: 'ម៉ាស៊ីនបញ្ចាំងស្លាយ Epson EB-X06 Projector', unit: 'គ្រឿង', stock: 8 },
    { id: 'NV-IT-003', name: 'ម៉ាស៊ីនព្រីនធ័រ Canon LBP2900 Laser', unit: 'គ្រឿង', stock: 5 },
    { id: 'NV-IT-004', name: 'កាមេរ៉ាសុវត្ថិភាព Hikvision IP Camera', unit: 'គ្រាប់', stock: 12 },
    { id: 'NV-IT-005', name: 'ដុំ WiFi Router MikroTik hEX S', unit: 'គ្រឿង', stock: 6 }
  ],
  'សម្ភារៈការិយាល័យ & រដ្ឋបាល': [
    { id: 'NV-OFF-001', name: 'ក្រដាស A4 Double A 80gsm (កេស ៥ដុំ)', unit: 'កេស', stock: 45 },
    { id: 'NV-OFF-002', name: 'ប៊ិចសរសេរបុគ្គលិក Pilot Ballpen (ប្រអប់)', unit: 'ប្រអប់', stock: 30 },
    { id: 'NV-OFF-003', name: 'ហ្វឺតសរសេរក្តារខៀន Whiteboard Marker', unit: 'ប្រអប់', stock: 50 },
    { id: 'NV-OFF-004', name: 'ប្រដាប់កៀបក្រដាស Stapler Max HD-50', unit: 'ដើម', stock: 18 }
  ],
  'សៀវភៅ & ឯកសារសិក្សា': [
    { id: 'NV-BOK-001', name: 'សៀវភៅគណិតវិទ្យា ថ្នាក់ទី ១២ (ក្រសួង)', unit: 'ក្បាល', stock: 120 },
    { id: 'NV-BOK-002', name: 'សៀវភៅភាសាខ្មែរ ថ្នាក់ទី ១០ (ក្រសួង)', unit: 'ក្បាល', stock: 95 },
    { id: 'NV-BOK-003', name: 'វចនានុក្រមអង់គ្លេស-ខ្មែរ Oxford', unit: 'ក្បាល', stock: 25 }
  ],
  'សម្ភារៈបន្ទប់ពិសោធន៍ (Lab)': [
    { id: 'NV-LAB-001', name: 'មីក្រូទស្សន៍ជីវវិទ្យា Olympus CX23', unit: 'គ្រឿង', stock: 15 },
    { id: 'NV-LAB-002', name: 'បំពង់កែវសាកពិសោធន៍ Test Tubes (កញ្ចប់)', unit: 'កញ្ចប់', stock: 40 },
    { id: 'NV-LAB-003', name: 'ម៉ូដែលរចនាសម្ព័ន្ធមនុស្ស Anatomy Model', unit: 'ឈុត', stock: 4 }
  ],
  'គ្រឿងសង្ហារិម & តុ កៅអី': [
    { id: 'NV-FRN-001', name: 'តុ និងកៅអីសិស្សឈើប្រណិត (ឈុត)', unit: 'ឈុត', stock: 60 },
    { id: 'NV-FRN-002', name: 'កៅអីការិយាល័យវិល Mesh Office Chair', unit: 'កៅអី', stock: 14 },
    { id: 'NV-FRN-003', name: 'ក្តារខៀនសរសេរប៊ិច Magnetic Whiteboard', unit: 'ផ្ទាំង', stock: 10 }
  ]
};

// In-Memory Storage for Requests & User Wizard Sessions
let requests = [];
if (fs.existsSync(DATA_FILE)) {
  try {
    requests = JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
  } catch (e) {
    requests = [];
  }
}

async function syncRequestToSupabase(reqItem) {
  if (!config.supabaseUrl || !config.supabaseKey) return;
  try {
    const url = `${config.supabaseUrl.replace(/\/+$/, '')}/rest/v1/stock_out`;
    let mappedStatus = 'រង់ចាំអនុម័ត';
    if (reqItem.status === 'APPROVED') mappedStatus = 'បានអនុម័ត';
    else if (reqItem.status === 'REJECTED') mappedStatus = 'បដិសេធ';

    await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'apikey': config.supabaseKey,
        'Authorization': `Bearer ${config.supabaseKey}`,
        'Prefer': 'resolution=merge-duplicates'
      },
      body: JSON.stringify({
        id: reqItem.id,
        item_id: reqItem.itemId,
        item_name: reqItem.itemName,
        category: reqItem.category || 'ទូទៅ',
        qty: reqItem.qty,
        purpose: reqItem.purpose || '',
        req_name: reqItem.staffName || '',
        req_dept: 'Telegram Bot',
        appr_name: reqItem.approvedBy || '',
        status: mappedStatus
      })
    });
  } catch (e) {
    console.warn('Supabase bot sync error:', e.message);
  }
}

function saveRequests(latestItem = null) {
  try {
    fs.writeFileSync(DATA_FILE, JSON.stringify(requests, null, 2), 'utf8');
    if (latestItem) {
      syncRequestToSupabase(latestItem).catch(() => {});
    } else if (requests.length > 0) {
      syncRequestToSupabase(requests[requests.length - 1]).catch(() => {});
    }
  } catch (e) {
    console.error('Error saving requests to file:', e.message);
  }
}

// User conversation sessions: chatId -> { step, category, item, qty, purpose, userName }
const userSessions = new Map();

// 2. TELEGRAM API HELPER METHODS
async function apiCall(method, payload) {
  if (!config.botToken) {
    throw new Error('Bot token is not configured! Please set botToken in telegram_bot_config.json');
  }
  const url = `https://api.telegram.org/bot${config.botToken}/${method}`;
  const res = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  });
  const data = await res.json();
  if (!data.ok) {
    throw new Error(`Telegram API Error (${method}): ${data.description}`);
  }
  return data.result;
}

async function sendMessage(chatId, text, extra = {}) {
  return apiCall('sendMessage', {
    chat_id: chatId,
    text: text,
    parse_mode: 'HTML',
    ...extra
  });
}

async function editMessage(chatId, messageId, text, extra = {}) {
  return apiCall('editMessageText', {
    chat_id: chatId,
    message_id: messageId,
    text: text,
    parse_mode: 'HTML',
    ...extra
  });
}

async function answerCallbackQuery(callbackQueryId, text = '', showAlert = false) {
  return apiCall('answerCallbackQuery', {
    callback_query_id: callbackQueryId,
    text: text,
    show_alert: showAlert
  });
}

// 3. PERSISTENT MAIN KEYBOARD (REPLY KEYBOARD)
function getMainReplyKeyboard() {
  return {
    reply_markup: {
      keyboard: [
        [{ text: '📝 ស្នើសុំដកសម្ភារៈ (Request Item)' }],
        [{ text: '📋 ប្រវត្តិសំណើរបស់ខ្ញុំ (My Requests)' }, { text: '❓ ជំនួយ (Help)' }]
      ],
      resize_keyboard: true,
      persistent: true
    }
  };
}

// 4. STEP 1: CATEGORY INLINE KEYBOARD
function getCategoriesInlineKeyboard() {
  const keyboard = [];
  const categories = Object.keys(CATALOG);
  
  // Arrange categories 2 per row
  for (let i = 0; i < categories.length; i += 2) {
    const row = [
      { text: `📁 ${categories[i]}`, callback_data: `cat_${i}` }
    ];
    if (categories[i + 1]) {
      row.push({ text: `📁 ${categories[i + 1]}`, callback_data: `cat_${i + 1}` });
    }
    keyboard.push(row);
  }
  keyboard.push([{ text: '❌ បោះបង់ (Cancel)', callback_data: 'cancel_wizard' }]);

  return {
    reply_markup: {
      inline_keyboard: keyboard
    }
  };
}

// 5. STEP 2: ITEMS INLINE KEYBOARD
function getItemsInlineKeyboard(categoryName, catIndex) {
  const items = CATALOG[categoryName] || [];
  const keyboard = [];

  items.forEach((item, itemIdx) => {
    keyboard.push([
      {
        text: `📦 ${item.name} (${item.stock} ${item.unit})`,
        callback_data: `item_${catIndex}_${itemIdx}`
      }
    ]);
  });

  keyboard.push([
    { text: '⬅️ ថយក្រោយ (Back)', callback_data: 'back_to_cat' },
    { text: '❌ បោះបង់ (Cancel)', callback_data: 'cancel_wizard' }
  ]);

  return {
    reply_markup: {
      inline_keyboard: keyboard
    }
  };
}

// 6. DISPATCH CONFIRMATION CARD TO STAFF
async function sendConfirmationSummary(chatId, session) {
  const msg = 
    `📋 <b>សូមពិនិត្យ និងបញ្ជាក់ពាក្យស្នើសុំដកសម្ភារៈ</b>\n` +
    `🏫 <b>${config.schoolName}</b>\n` +
    `-----------------------------------------\n` +
    `👤 <b>អ្នកស្នើសុំ:</b> ${session.userName}\n` +
    `📁 <b>ប្រភេទ:</b> ${session.category}\n` +
    `📦 <b>សម្ភារៈ:</b> <b>${session.item.name}</b>\n` +
    `🔢 <b>ចំនួនស្នើសុំ:</b> <b>${session.qty}</b> ${session.item.unit}\n` +
    `🎯 <b>គោលបំណង & ទីតាំង:</b> ${session.purpose}\n` +
    `-----------------------------------------\n` +
    `<i>តើព័ត៌មានខាងលើត្រឹមត្រូវហើយឬនៅ? សូមចុចប៊ូតុងខាងក្រោមដើម្បីបញ្ជាក់៖</i>`;

  const keyboard = {
    reply_markup: {
      inline_keyboard: [
        [
          { text: '✅ បញ្ជាក់ និងផ្ញើសំណើ (Confirm & Submit)', callback_data: 'confirm_submit' }
        ],
        [
          { text: '❌ បោះបង់ (Cancel)', callback_data: 'cancel_wizard' }
        ]
      ]
    }
  };

  await sendMessage(chatId, msg, keyboard);
}

// 7. DISPATCH ACTIONABLE CARD TO STOCK KEEPER
async function dispatchToStockKeeper(req) {
  if (!config.stockKeeperChatId) {
    console.warn('⚠️ Stock Keeper Chat ID is not configured. Skipping direct dispatch.');
    return;
  }

  const msg = 
    `🔔 <b>[ពាក្យស្នើសុំដកសម្ភារៈថ្មី - រង់ចាំការបញ្ជាក់ស្តុក]</b>\n` +
    `🏫 <b>${config.schoolName}</b>\n` +
    `-----------------------------------------\n` +
    `🆔 <b>លេខកូដសំណើ:</b> <code>${req.id}</code>\n` +
    `👤 <b>អ្នកស្នើសុំ:</b> <b>${req.staffName}</b> (@${req.username || 'N/A'})\n` +
    `📦 <b>សម្ភារៈ:</b> <b>${req.itemName}</b> (កូដ: ${req.itemId})\n` +
    `🔢 <b>ចំនួនស្នើសុំ:</b> <b>${req.qty}</b> ${req.unit}\n` +
    `📊 <b>ស្តុកជាក់ស្តែងក្នុងឃ្លាំង:</b> <b>${req.stockAvailable}</b> ${req.unit} (${req.stockAvailable >= req.qty ? 'គ្រប់គ្រាន់ ✅' : 'ខ្វះខាត ⚠️'})\n` +
    `🎯 <b>គោលបំណង & ទីតាំង:</b> ${req.purpose}\n` +
    `⏰ <b>ម៉ោងស្នើសុំ:</b> ${req.createdAt}\n` +
    `-----------------------------------------\n` +
    `👨‍💼 <i>សូមអ្នកគ្រប់គ្រងស្តុកពិនិត្យចំនួនជាក់ស្តែង និងចុចបញ្ជូនបន្តទៅកាន់លោកនាយក៖</i>`;

  const keyboard = {
    reply_markup: {
      inline_keyboard: [
        [
          { text: '📦 បញ្ជាក់ស្តុកគ្រប់ & បញ្ជូនទៅនាយក', callback_data: `stk_ok_${req.id}` }
        ],
        [
          { text: '⚠️ ស្តុកមិនគ្រប់', callback_data: `stk_low_${req.id}` },
          { text: '❌ បដិសេធសំណើ', callback_data: `stk_rej_${req.id}` }
        ]
      ]
    }
  };

  try {
    const targetChat = config.stockKeeperChatId || config.approvalGroupChatId;
    if (targetChat) {
      const sent = await sendMessage(targetChat, msg, keyboard);
      req.stockMsgId = sent.message_id;
      saveRequests();
    }
    // Also post to group if distinct from personal chat
    if (config.approvalGroupChatId && config.approvalGroupChatId !== config.stockKeeperChatId) {
      await sendMessage(config.approvalGroupChatId, msg, keyboard);
    }
  } catch (err) {
    console.error('Failed to notify Stock Keeper:', err.message);
  }
}

// 8. DISPATCH ACTIONABLE CARD TO DIRECTOR
async function dispatchToDirector(req) {
  if (!config.directorChatId) {
    console.warn('⚠️ Director Chat ID is not configured. Skipping dispatch to Director.');
    return;
  }

  const msg = 
    `👑 <b>[ពាក្យស្នើសុំដកសម្ភារៈ - រង់ចាំលោកនាយកអនុម័ត]</b>\n` +
    `🏫 <b>${config.schoolName}</b>\n` +
    `-----------------------------------------\n` +
    `🆔 <b>លេខកូដសំណើ:</b> <code>${req.id}</code>\n` +
    `👤 <b>អ្នកស្នើសុំ:</b> <b>${req.staffName}</b> (@${req.username || 'N/A'})\n` +
    `📦 <b>សម្ភារៈ:</b> <b>${req.itemName}</b>\n` +
    `🔢 <b>ចំនួនស្នើសុំ:</b> <b>${req.qty}</b> ${req.unit}\n` +
    `🎯 <b>គោលបំណង & ទីតាំង:</b> ${req.purpose}\n` +
    `👨‍💼 <b>អ្នកកាន់ស្តុក (ពិនិត្យរួច):</b> លោក សុខ ចាន់រិទ្ធ (បានបញ្ជាក់ថាស្តុកមានគ្រប់គ្រាន់ ✅)\n` +
    `⏰ <b>កាលបរិច្ឆេទ:</b> ${req.createdAt}\n` +
    `-----------------------------------------\n` +
    `<i>សូមលោកនាយកពិនិត្យ និងសម្រេចអនុម័តលើការដកសម្ភារៈនេះ៖</i>`;

  const keyboard = {
    reply_markup: {
      inline_keyboard: [
        [
          { text: '✅ អនុម័ត (Approve)', callback_data: `dir_app_${req.id}` },
          { text: '❌ បដិសេធ (Reject)', callback_data: `dir_rej_${req.id}` }
        ]
      ]
    }
  };

  try {
    const targetChat = config.directorChatId || config.approvalGroupChatId;
    if (targetChat) {
      const sent = await sendMessage(targetChat, msg, keyboard);
      req.dirMsgId = sent.message_id;
      saveRequests();
    }
    // Also post to group if distinct from personal chat
    if (config.approvalGroupChatId && config.approvalGroupChatId !== config.directorChatId) {
      await sendMessage(config.approvalGroupChatId, msg, keyboard);
    }
  } catch (err) {
    console.error('Failed to notify Director:', err.message);
  }
}

// 9. HANDLE TEXT MESSAGES
async function handleMessage(msg) {
  const chatId = msg.chat.id;
  const text = (msg.text || '').trim();
  const userName = [msg.from?.first_name, msg.from?.last_name].filter(Boolean).join(' ') || msg.from?.username || 'បុគ្គលិក';
  const username = msg.from?.username || '';

  // Get or initialize session
  let session = userSessions.get(chatId);

  // Command /start
  if (text === '/start') {
    userSessions.delete(chatId);
    const welcome = 
      `👋 <b>សូមស្វាគមន៍មកកាន់ប្រព័ន្ធ Telegram Bot របស់ ${config.schoolName}!</b>\n\n` +
      `លោកគ្រូ អ្នកគ្រូ និងបុគ្គលិកទាំងអស់អាចស្នើសុំដកសម្ភារៈប្រើប្រាស់ក្នុងការិយាល័យ ឬថ្នាក់រៀនបានយ៉ាងងាយស្រួល និងរហ័សតាមរយៈ Bot នេះ។\n\n` +
      `🔹 <b>របៀបប្រើប្រាស់:</b>\n` +
      `1. ចុចប៊ូតុង <b>«📝 ស្នើសុំដកសម្ភារៈ»</b>\n` +
      `2. ជ្រើសរើសប្រភេទ និងមុខសម្ភារៈ\n` +
      `3. វាយបញ្ចូលចំនួន និងគោលបំណង\n` +
      `4. សំណើនឹងត្រូវបញ្ជូនទៅកាន់ <b>អ្នកកាន់ស្តុក</b> និង <b>លោកនាយក</b> ដើម្បីអនុម័ត!\n\n` +
      `👉 <i>សូមចុចប៊ូតុងខាងក្រោមដើម្បីចាប់ផ្តើម៖</i>`;

    await sendMessage(chatId, welcome, getMainReplyKeyboard());
    return;
  }

  // Help command
  if (text === '❓ ជំនួយ (Help)' || text === '/help') {
    const helpMsg = 
      `ℹ️ <b>ការណែនាំ និងជំនួយពីប្រព័ន្ធសារពើភ័ណ្ឌ New Vision:</b>\n\n` +
      `• <b>/request</b> : ចាប់ផ្តើមពាក្យស្នើសុំដកសម្ភារៈថ្មី\n` +
      `• <b>/myrequests</b> : ពិនិត្យប្រវត្តិ និងស្ថានភាពសំណើរបស់អ្នក\n` +
      `• <b>/myid</b> : មើល Chat ID របស់អ្នកសម្រាប់ផ្ញើជូន Admin\n\n` +
      `📞 <b>ទំនាក់ទំនងការិយាល័យរដ្ឋបាល:</b> 012 345 678\n` +
      `👨‍💼 <b>អ្នកកាន់ស្តុក:</b> លោក សុខ ចាន់រិទ្ធ (011 223 344)\n` +
      `👑 <b>នាយកសាលា:</b> លោក ហ៊ុយ ចាន់ពិសី (012 345 678)`;
    await sendMessage(chatId, helpMsg, getMainReplyKeyboard());
    return;
  }

  // Command to get User's Chat ID
  if (text === '/myid') {
    await sendMessage(chatId, `🆔 <b>Chat ID របស់អ្នកគឺ:</b> <code>${chatId}</code>\n<i>(សូមចម្លងលេខកូដនេះផ្ញើជូនលោកនាយក ឬរដ្ឋបាល ប្រសិនបើអ្នកជាអ្នកកាន់ស្តុក ឬនាយកសាលា)</i>`);
    return;
  }

  // 1-Click Director Registration (No manual Chat ID typing!)
  if (text === '/set_director' || text === '/register director') {
    config.directorChatId = String(chatId);
    try {
      fs.writeFileSync(CONFIG_FILE, JSON.stringify(config, null, 2), 'utf8');
    } catch (e) {}
    await sendMessage(chatId, `👑 <b>[កំណត់តួនាទីជោគជ័យ]</b>\nសួស្តី <b>${userName}</b>! លោកអ្នកត្រូវបានកំណត់ជា <b>នាយកសាលា (Director)</b> ដោយជោគជ័យ!\nចាប់ពីពេលនេះ សំណើដកសម្ភារៈទាំងអស់នឹងត្រូវផ្ញើមកកាន់លោកអ្នកដើម្បីពិនិត្យ និងចុច Approve។`);
    return;
  }

  // 1-Click Stock Keeper Registration
  if (text === '/set_stock' || text === '/register stock') {
    config.stockKeeperChatId = String(chatId);
    try {
      fs.writeFileSync(CONFIG_FILE, JSON.stringify(config, null, 2), 'utf8');
    } catch (e) {}
    await sendMessage(chatId, `📦 <b>[កំណត់តួនាទីជោគជ័យ]</b>\nសួស្តី <b>${userName}</b>! លោកអ្នកត្រូវបានកំណត់ជា <b>អ្នកកាន់ស្តុក (Stock Keeper)</b> ដោយជោគជ័យ!\nចាប់ពីពេលនេះ សំណើដកសម្ភារៈពីបុគ្គលិកនឹងត្រូវផ្ញើមកកាន់លោកអ្នកដើម្បីពិនិត្យឃ្លាំង។`);
    return;
  }

  // 1-Click Group Registration (when added to a Telegram Group)
  if (text === '/set_group' || text === '/register group') {
    config.approvalGroupChatId = String(chatId);
    try {
      fs.writeFileSync(CONFIG_FILE, JSON.stringify(config, null, 2), 'utf8');
    } catch (e) {}
    await sendMessage(chatId, `🏫 <b>[កំណត់ក្រុមជោគជ័យ]</b>\nក្រុមនេះត្រូវបានកំណត់ជា <b>ក្រុមអនុម័តសំណើសម្ភារៈសាលា (Approval Group)</b>!\nរាល់ពេលមានគ្រូ ឬបុគ្គលិកស្នើសុំសម្ភារៈ កាតសំណើនឹងត្រូវទម្លាក់មកក្នុងក្រុមនេះ ដើម្បីឱ្យអ្នកកាន់ស្តុក និងលោកនាយក Approve ផ្ទាល់ក្នុងក្រុមនេះតែម្តង!`);
    return;
  }

  // My Requests list
  if (text === '📋 ប្រវត្តិសំណើរបស់ខ្ញុំ (My Requests)' || text === '/myrequests') {
    const myReqs = requests.filter(r => r.chatId === chatId);
    if (myReqs.length === 0) {
      await sendMessage(chatId, '📭 លោកអ្នកមិនទាន់មានប្រវត្តិស្នើសុំដកសម្ភារៈនៅឡើយទេ។', getMainReplyKeyboard());
      return;
    }

    let summary = `📋 <b>ប្រវត្តិសំណើរបស់អ្នក (${myReqs.length} លើក):</b>\n\n`;
    myReqs.slice(-5).reverse().forEach((r, idx) => {
      let statusIcon = '⏳';
      if (r.status === 'APPROVED') statusIcon = '✅ បានអនុម័ត';
      else if (r.status === 'REJECTED') statusIcon = '❌ បានបដិសេធ';
      else if (r.status === 'PENDING_DIRECTOR') statusIcon = '👑 រង់ចាំនាយកអនុម័ត';
      else statusIcon = '📦 រង់ចាំអ្នកកាន់ស្តុកបញ្ជាក់';

      summary += `${idx + 1}. <b>${r.itemName}</b> (${r.qty} ${r.unit})\n` +
        `   • កូដ: <code>${r.id}</code> | ស្ថានភាព: <b>${statusIcon}</b>\n` +
        `   • កាលបរិច្ឆេទ: ${r.createdAt}\n\n`;
    });

    await sendMessage(chatId, summary, getMainReplyKeyboard());
    return;
  }

  // Start Material Request Wizard
  if (text === '📝 ស្នើសុំដកសម្ភារៈ (Request Item)' || text === '/request') {
    userSessions.set(chatId, {
      step: 'AWAITING_CATEGORY',
      userName,
      username
    });

    const prompt = 
      `📁 <b>ជំហានទី ១/៤: ជ្រើសរើសប្រភេទសម្ភារៈ (Category)</b>\n\n` +
      `សូមជ្រើសរើសប្រភេទសម្ភារៈដែលលោកអ្នកត្រូវការដកប្រើប្រាស់ពីបញ្ជីខាងក្រោម៖`;

    await sendMessage(chatId, prompt, getCategoriesInlineKeyboard());
    return;
  }

  // Wizard Step: AWAITING_QTY
  if (session && session.step === 'AWAITING_QTY') {
    const qty = parseInt(text, 10);
    if (isNaN(qty) || qty <= 0) {
      await sendMessage(chatId, '⚠️ ចំនួនមិនត្រឹមត្រូវទេ! សូមវាយបញ្ចូលជាលេខគត់ធំជាង ០ (ឧទាហរណ៍: 1 ឬ 2 ឬ 5):');
      return;
    }

    if (qty > session.item.stock) {
      await sendMessage(chatId, `⚠️ ចំនួនដែលអ្នកស្នើសុំ (${qty} ${session.item.unit}) ច្រើនជាងចំនួនស្តុកជាក់ស្តែងដែលមាន (${session.item.stock} ${session.item.unit})! សូមវាយបញ្ចូលចំនួនតិចជាង ឬស្មើចំនួនស្តុក:`);
      return;
    }

    session.qty = qty;
    session.step = 'AWAITING_PURPOSE';
    userSessions.set(chatId, session);

    const prompt = 
      `🎯 <b>ជំហានទី ៤/៤: បញ្ជាក់គោលបំណង និងទីតាំងប្រើប្រាស់</b>\n\n` +
      `សូមវាយបញ្ចូលគោលបំណងនៃការយកទៅប្រើ និងទីតាំងជាក់លាក់៖\n` +
      `<i>(ឧទាហរណ៍: យកទៅបង្រៀនសិស្សថ្នាក់ 11B អាគារ B ជាន់ទី២ ឬ ប្រើប្រាស់ក្នុងការិយាល័យរដ្ឋបាល)</i>`;

    await sendMessage(chatId, prompt);
    return;
  }

  // Wizard Step: AWAITING_PURPOSE
  if (session && session.step === 'AWAITING_PURPOSE') {
    if (text.length < 3) {
      await sendMessage(chatId, '⚠️ សូមសរសេរគោលបំណងឱ្យបានច្បាស់លាស់បន្តិច (យ៉ាងហោចណាស់ ៣ តួអក្សរ):');
      return;
    }

    session.purpose = text;
    session.step = 'AWAITING_CONFIRM';
    userSessions.set(chatId, session);

    await sendConfirmationSummary(chatId, session);
    return;
  }

  // Fallback for unhandled messages
  await sendMessage(chatId, '❓ មិនយល់ពាក្យបញ្ជានេះទេ។ សូមចុច <b>«📝 ស្នើសុំដកសម្ភារៈ»</b> ដើម្បីធ្វើសំណើថ្មី ឬចុច /help សម្រាប់ជំនួយ។', getMainReplyKeyboard());
}

// 10. HANDLE CALLBACK QUERIES (BUTTON CLICKS)
async function handleCallbackQuery(cq) {
  const data = cq.data;
  const chatId = cq.message.chat.id;
  const messageId = cq.message.message_id;
  const fromName = [cq.from?.first_name, cq.from?.last_name].filter(Boolean).join(' ') || cq.from?.username || 'អ្នកប្រើប្រាស់';

  let session = userSessions.get(chatId);

  // Cancel Wizard
  if (data === 'cancel_wizard') {
    userSessions.delete(chatId);
    await answerCallbackQuery(cq.id, 'បានបោះបង់ការស្នើសុំ');
    await editMessage(chatId, messageId, '❌ <b>ការស្នើសុំដកសម្ភារៈត្រូវបានបោះបង់។</b> លោកអ្នកអាចចុច «📝 ស្នើសុំដកសម្ភារៈ» ឡើងវិញគ្រប់ពេលវេលា។');
    return;
  }

  // Back to Categories
  if (data === 'back_to_cat') {
    if (session) {
      session.step = 'AWAITING_CATEGORY';
      userSessions.set(chatId, session);
    }
    await answerCallbackQuery(cq.id);
    await editMessage(chatId, messageId, '📁 <b>ជំហានទី ១/៤: ជ្រើសរើសប្រភេទសម្ភារៈ (Category)</b>\n\nសូមជ្រើសរើសប្រភេទសម្ភារៈដែលលោកអ្នកត្រូវការដកប្រើប្រាស់ពីបញ្ជីខាងក្រោម៖', getCategoriesInlineKeyboard());
    return;
  }

  // Select Category (cat_X)
  if (data.startsWith('cat_')) {
    const catIdx = parseInt(data.replace('cat_', ''), 10);
    const categories = Object.keys(CATALOG);
    const selectedCategory = categories[catIdx];

    if (!session) {
      session = { userName: fromName, username: cq.from?.username || '' };
    }
    session.category = selectedCategory;
    session.catIndex = catIdx;
    session.step = 'AWAITING_ITEM';
    userSessions.set(chatId, session);

    await answerCallbackQuery(cq.id, `បានជ្រើសរើស ${selectedCategory}`);
    const prompt = 
      `📦 <b>ជំហានទី ២/៤: ជ្រើសរើសមុខសម្ភារៈ (Item)</b>\n` +
      `📁 ប្រភេទ: <b>${selectedCategory}</b>\n\n` +
      `សូមជ្រើសរើសមុខសម្ភារៈជាក់លាក់ដែលអ្នកត្រូវការដកពីឃ្លាំង៖`;

    await editMessage(chatId, messageId, prompt, getItemsInlineKeyboard(selectedCategory, catIdx));
    return;
  }

  // Select Item (item_C_I)
  if (data.startsWith('item_')) {
    const parts = data.split('_');
    const catIdx = parseInt(parts[1], 10);
    const itemIdx = parseInt(parts[2], 10);
    const categories = Object.keys(CATALOG);
    const categoryName = categories[catIdx];
    const item = CATALOG[categoryName][itemIdx];

    if (!session) {
      session = { userName: fromName, username: cq.from?.username || '' };
    }
    session.category = categoryName;
    session.item = item;
    session.step = 'AWAITING_QTY';
    userSessions.set(chatId, session);

    await answerCallbackQuery(cq.id, `បានជ្រើសរើស ${item.name}`);
    await editMessage(chatId, messageId, 
      `✅ <b>បានជ្រើសរើស:</b> <b>${item.name}</b>\n` +
      `📊 ស្តុកក្នុងឃ្លាំងបច្ចុប្បន្ន: <b>${item.stock}</b> ${item.unit}\n\n` +
      `🔢 <b>ជំហានទី ៣/៤: សូមវាយបញ្ចូលចំនួនដែលត្រូវការដក:</b>\n` +
      `<i>(សូមវាយបញ្ចូលជាលេខក្នុងប្រអប់ Chat ខាងក្រោម ឧ. 1 ឬ 2 ឬ 5)</i>`
    );
    return;
  }

  // Confirm and Submit Request
  if (data === 'confirm_submit') {
    if (!session || !session.item) {
      await answerCallbackQuery(cq.id, 'Session បានផុតកំណត់! សូមចាប់ផ្តើមម្តងទៀត។', true);
      return;
    }

    const now = new Date();
    const reqId = 'REQ-' + now.getFullYear() + String(now.getMonth() + 1).padStart(2, '0') + String(now.getDate()).padStart(2, '0') + '-' + Math.floor(1000 + Math.random() * 9000);

    const newReq = {
      id: reqId,
      chatId: chatId,
      staffName: session.userName,
      username: session.username,
      category: session.category,
      itemId: session.item.id,
      itemName: session.item.name,
      qty: session.qty,
      unit: session.item.unit,
      stockAvailable: session.item.stock,
      purpose: session.purpose,
      status: 'PENDING_STOCK_VERIFY', // Step 1 status
      createdAt: now.toLocaleString('km-KH', { year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit' }),
      timestamp: now.toISOString()
    };

    requests.push(newReq);
    saveRequests();
    userSessions.delete(chatId);

    await answerCallbackQuery(cq.id, '🎉 សំណើត្រូវបានដាក់ជូនដោយជោគជ័យ!');

    // Success response to Staff
    const staffSuccessMsg = 
      `🎉 <b>ការដាក់ពាក្យស្នើសុំដកសម្ភារៈជោគជ័យ!</b>\n` +
      `🏫 <b>${config.schoolName}</b>\n` +
      `-----------------------------------------\n` +
      `🆔 <b>លេខកូដសំណើ:</b> <code>${newReq.id}</code>\n` +
      `📦 <b>សម្ភារៈ:</b> <b>${newReq.itemName}</b> (${newReq.qty} ${newReq.unit})\n` +
      `🎯 <b>គោលបំណង:</b> ${newReq.purpose}\n` +
      `⏳ <b>ស្ថានភាពបច្ចុប្បន្ន:</b> <b>រង់ចាំការបញ្ជាក់ស្តុកពីអ្នកកាន់ស្តុក</b>\n` +
      `-----------------------------------------\n` +
      `ℹ️ <i>ប្រព័ន្ធបានបញ្ជូនសំណើរបស់អ្នកទៅកាន់អ្នកគ្រប់គ្រងស្តុក (លោក សុខ ចាន់រិទ្ធ) រួចរាល់ហើយ។ ពេលមានការបញ្ជាក់ និងអនុម័ត ប្រព័ន្ធនឹងផ្ញើសារដំណឹងជូនអ្នកភ្លាមៗ!</i>`;

    await editMessage(chatId, messageId, staffSuccessMsg);

    // Forward to Stock Keeper
    await dispatchToStockKeeper(newReq);
    return;
  }

  // --------------------------------------------------------------------------
  // STOCK KEEPER ACTIONS: stk_ok_REQ, stk_low_REQ, stk_rej_REQ
  // --------------------------------------------------------------------------
  if (data.startsWith('stk_ok_')) {
    const reqId = data.replace('stk_ok_', '');
    const req = requests.find(r => r.id === reqId);
    if (!req) {
      await answerCallbackQuery(cq.id, 'រកមិនឃើញសំណើនេះទេ!', true);
      return;
    }

    req.status = 'PENDING_DIRECTOR';
    req.verifiedBy = fromName;
    req.verifiedAt = new Date().toLocaleString('km-KH');
    saveRequests();

    await answerCallbackQuery(cq.id, '✅ បានបញ្ជាក់ស្តុក និងបញ្ជូនទៅលោកនាយក!');

    // Update Stock Keeper message
    const updatedStockMsg = 
      `✅ <b>[បានបញ្ជាក់ស្តុក និងបញ្ជូនទៅលោកនាយក]</b>\n` +
      `🆔 <b>កូដ:</b> <code>${req.id}</code> | <b>អ្នកស្នើសុំ:</b> ${req.staffName}\n` +
      `📦 <b>សម្ភារៈ:</b> ${req.itemName} (${req.qty} ${req.unit})\n` +
      `👨‍💼 <b>អ្នកបញ្ជាក់:</b> ${fromName} (${req.verifiedAt})\n` +
      `👑 <i>សំណើនេះត្រូវបានបញ្ជូនទៅកាន់លោកនាយកសាលារួចរាល់ហើយ។</i>`;

    await editMessage(chatId, messageId, updatedStockMsg);

    // Forward to Director
    await dispatchToDirector(req);

    // Notify Staff
    await sendMessage(req.chatId, 
      `📦 <b>[ដំណឹងបច្ចុប្បន្នភាពសំណើ: ${req.id}]</b>\n` +
      `អ្នកគ្រប់គ្រងស្តុក (${fromName}) បានពិនិត្យបញ្ជាក់ថាស្តុកមានគ្រប់គ្រាន់រួចរាល់ហើយ និងបានបញ្ជូនបន្តទៅកាន់ <b>លោកនាយកសាលា</b> ដើម្បីសម្រេចអនុម័តជាផ្លូវការ!`
    );
    return;
  }

  if (data.startsWith('stk_rej_') || data.startsWith('stk_low_')) {
    const isLow = data.startsWith('stk_low_');
    const reqId = data.replace(isLow ? 'stk_low_' : 'stk_rej_', '');
    const req = requests.find(r => r.id === reqId);
    if (!req) {
      await answerCallbackQuery(cq.id, 'រកមិនឃើញសំណើនេះទេ!', true);
      return;
    }

    req.status = 'REJECTED';
    req.rejectedBy = fromName;
    req.rejectReason = isLow ? 'ស្តុកក្នុងឃ្លាំងមិនគ្រប់គ្រាន់' : 'អ្នកកាន់ស្តុកបានបដិសេធសំណើ';
    req.rejectedAt = new Date().toLocaleString('km-KH');
    saveRequests();

    await answerCallbackQuery(cq.id, '❌ បានបដិសេធសំណើ');

    await editMessage(chatId, messageId, 
      `❌ <b>[បានបដិសេធសំណើដោយអ្នកកាន់ស្តុក]</b>\n` +
      `🆔 <b>កូដ:</b> <code>${req.id}</code> | <b>អ្នកស្នើសុំ:</b> ${req.staffName}\n` +
      `📦 <b>សម្ភារៈ:</b> ${req.itemName} (${req.qty} ${req.unit})\n` +
      `⚠️ <b>មូលហេតុ:</b> ${req.rejectReason}\n` +
      `⏰ <b>ម៉ោងបដិសេធ:</b> ${req.rejectedAt}`
    );

    // Notify Staff
    await sendMessage(req.chatId, 
      `❌ <b>[សេចក្តីជូនដំណឹង: សំណើដកសម្ភារៈត្រូវបានបដិសេធ]</b>\n` +
      `ពាក្យស្នើសុំលេខ <code>${req.id}</code> សម្រាប់សម្ភារៈ <b>${req.itemName}</b> (${req.qty} ${req.unit}) មិនត្រូវបានអនុញ្ញាតទេ៖\n` +
      `⚠️ <b>មូលហេតុ:</b> ${req.rejectReason} (ដោយអ្នកកាន់ស្តុក: ${fromName})\n\n` +
      `👉 សូមទាក់ទងអ្នកកាន់ស្តុកសម្រាប់ព័ត៌មានបន្ថែម។`
    );
    return;
  }

  // --------------------------------------------------------------------------
  // DIRECTOR ACTIONS: dir_app_REQ, dir_rej_REQ
  // --------------------------------------------------------------------------
  if (data.startsWith('dir_app_')) {
    const reqId = data.replace('dir_app_', '');
    const req = requests.find(r => r.id === reqId);
    if (!req) {
      await answerCallbackQuery(cq.id, 'រកមិនឃើញសំណើនេះទេ!', true);
      return;
    }

    req.status = 'APPROVED';
    req.approvedBy = fromName;
    req.approvedAt = new Date().toLocaleString('km-KH');
    
    // Deduct stock in catalog
    for (const cat in CATALOG) {
      const found = CATALOG[cat].find(it => it.id === req.itemId);
      if (found) {
        found.stock = Math.max(0, found.stock - req.qty);
        break;
      }
    }
    saveRequests();

    await answerCallbackQuery(cq.id, '🎉 បានអនុម័តការដកសម្ភារៈដោយជោគជ័យ!');

    // Update Director message
    await editMessage(chatId, messageId, 
      `👑 <b>[លោកនាយកបានអនុម័តការដកសម្ភារៈរួចរាល់]</b>\n` +
      `🆔 <b>លេខកូដសំណើ:</b> <code>${req.id}</code>\n` +
      `👤 <b>អ្នកស្នើសុំ:</b> <b>${req.staffName}</b>\n` +
      `📦 <b>សម្ភារៈ:</b> <b>${req.itemName}</b> (${req.qty} ${req.unit})\n` +
      `🎯 <b>គោលបំណង:</b> ${req.purpose}\n` +
      `✅ <b>អនុម័តដោយ:</b> លោកនាយក ${fromName} (${req.approvedAt})\n` +
      `-----------------------------------------\n` +
      `<i>ប្រព័ន្ធបានបញ្ជូនដំណឹងអនុម័តទៅកាន់អ្នកកាន់ស្តុក និងបុគ្គលិករួចរាល់ហើយ។</i>`
    );

    // Notify Staff (Congratulatory message)
    await sendMessage(req.chatId, 
      `🎉 <b>[ដំណឹងល្អ: សំណើដកសម្ភារៈត្រូវបានលោកនាយកអនុម័ត!]</b>\n` +
      `🏫 <b>${config.schoolName}</b>\n` +
      `-----------------------------------------\n` +
      `🆔 <b>លេខកូដសំណើ:</b> <code>${req.id}</code>\n` +
      `📦 <b>សម្ភារៈ:</b> <b>${req.itemName}</b> (ចំនួន: <b>${req.qty}</b> ${req.unit})\n` +
      `✅ <b>ស្ថានភាព:</b> <b>បានអនុម័ត (APPROVED)</b>\n` +
      `👑 <b>អនុម័តដោយ:</b> លោកនាយកសាលា (${req.approvedAt})\n` +
      `-----------------------------------------\n` +
      `👉 <b>សូមលោកគ្រូ/អ្នកគ្រូ អញ្ជើញទៅជួបអ្នកកាន់ស្តុក (លោក សុខ ចាន់រិទ្ធ) ដើម្បីទទួលយកសម្ភារៈជាក់ស្តែង។ អរគុណ!</b>`
    );

    // Notify Stock Keeper to issue items
    if (config.stockKeeperChatId) {
      await sendMessage(config.stockKeeperChatId, 
        `🔔 <b>[លោកនាយកបានអនុម័តសំណើដកសម្ភារៈ: ${req.id}]</b>\n` +
        `👤 <b>អ្នកស្នើសុំ:</b> <b>${req.staffName}</b>\n` +
        `📦 <b>សម្ភារៈត្រូវប្រគល់:</b> <b>${req.itemName}</b> (ចំនួន: <b>${req.qty}</b> ${req.unit})\n` +
        `🎯 <b>គោលបំណង:</b> ${req.purpose}\n` +
        `👑 <b>ស្ថានភាព:</b> បានទទួលការអនុម័តជាផ្លូវការពីលោកនាយកសាលា ✅\n` +
        `-----------------------------------------\n` +
        `👉 <b>សូមអ្នកកាន់ស្តុករៀបចំប្រគល់សម្ភារៈជូនបុគ្គលិកខាងលើ។</b>`
      );
    }
    return;
  }

  if (data.startsWith('dir_rej_')) {
    const reqId = data.replace('dir_rej_', '');
    const req = requests.find(r => r.id === reqId);
    if (!req) {
      await answerCallbackQuery(cq.id, 'រកមិនឃើញសំណើនេះទេ!', true);
      return;
    }

    req.status = 'REJECTED';
    req.rejectedBy = fromName;
    req.rejectReason = 'លោកនាយកសាលាបានបដិសេធសំណើ';
    req.rejectedAt = new Date().toLocaleString('km-KH');
    saveRequests();

    await answerCallbackQuery(cq.id, '❌ បានបដិសេធសំណើ');

    // Update Director message
    await editMessage(chatId, messageId, 
      `❌ <b>[លោកនាយកបានបដិសេធសំណើដកសម្ភារៈនេះ]</b>\n` +
      `🆔 <b>លេខកូដសំណើ:</b> <code>${req.id}</code>\n` +
      `👤 <b>អ្នកស្នើសុំ:</b> ${req.staffName}\n` +
      `📦 <b>សម្ភារៈ:</b> ${req.itemName} (${req.qty} ${req.unit})\n` +
      `⏰ <b>កាលបរិច្ឆេទ:</b> ${req.rejectedAt}`
    );

    // Notify Staff
    await sendMessage(req.chatId, 
      `❌ <b>[សេចក្តីជូនដំណឹង: សំណើដកសម្ភារៈត្រូវបានបដិសេធ]</b>\n` +
      `ពាក្យស្នើសុំលេខ <code>${req.id}</code> សម្រាប់ <b>${req.itemName}</b> មិនត្រូវបានលោកនាយកសាលាអនុញ្ញាតឡើយ។\n` +
      `👉 សូមទាក់ទងការិយាល័យនាយកសម្រាប់ព័ត៌មានលម្អិត។`
    );

    // Notify Stock Keeper
    if (config.stockKeeperChatId) {
      await sendMessage(config.stockKeeperChatId, 
        `⚠️ <b>[លោកនាយកបានបដិសេធសំណើ: ${req.id}]</b>\n` +
        `សំណើដកសម្ភារៈរបស់ <b>${req.staffName}</b> មិនត្រូវបានលោកនាយកអនុម័តឡើយ។ សូមកុំទាន់ប្រគល់សម្ភារៈ។`
      );
    }
    return;
  }
}

// 11. LONG-POLLING LOOP
let lastUpdateId = 0;
let isPolling = false;

async function pollUpdates() {
  if (isPolling) return;
  isPolling = true;

  try {
    const updates = await apiCall('getUpdates', {
      offset: lastUpdateId + 1,
      timeout: 30,
      allowed_updates: ['message', 'callback_query']
    });

    for (const update of updates) {
      lastUpdateId = update.update_id;

      if (update.message) {
        await handleMessage(update.message);
      } else if (update.callback_query) {
        await handleCallbackQuery(update.callback_query);
      }
    }
  } catch (err) {
    if (err.message.includes('401') || err.message.includes('Unauthorized')) {
      console.error('\n❌ Telegram Token មិនត្រឹមត្រូវ! សូមពិនិត្យ botToken ក្នុង telegram_bot_config.json ឡើងវិញ។\n');
      process.exit(1);
    } else {
      console.warn('⚠️ Polling error:', err.message);
    }
  } finally {
    isPolling = false;
    setTimeout(pollUpdates, config.pollIntervalMs);
  }
}

// 11.5 BUILT-IN HTTP REST & REAL-TIME SYNC SERVER (PORT 3333)
const HTTP_PORT = config.httpPort || 3333;
let httpServer = null;

function startHttpApi() {
  httpServer = http.createServer((req, res) => {
    // Enable CORS for all clients (Local file://, localhost, GitHub Pages, Vercel)
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

    if (req.method === 'OPTIONS') {
      res.writeHead(204);
      res.end();
      return;
    }

    const host = req.headers.host || `localhost:${HTTP_PORT}`;
    const url = new URL(req.url, `http://${host}`);

    if (url.pathname === '/api/status' && req.method === 'GET') {
      res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
      res.end(JSON.stringify({
        status: 'online',
        serverTime: new Date().toISOString(),
        totalRequests: requests.length,
        schoolName: config.schoolName,
        stockKeeperConfigured: !!config.stockKeeperChatId,
        directorConfigured: !!config.directorChatId
      }));
      return;
    }

    if (url.pathname === '/api/requests' && req.method === 'GET') {
      res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
      res.end(JSON.stringify({
        success: true,
        count: requests.length,
        requests: requests
      }));
      return;
    }

    if (url.pathname === '/api/catalog' && req.method === 'GET') {
      res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
      res.end(JSON.stringify({
        success: true,
        catalog: CATALOG
      }));
      return;
    }

    // Endpoint to allow Web App to trigger Director Approval directly
    if (url.pathname === '/api/approve' && req.method === 'POST') {
      let body = '';
      req.on('data', chunk => { body += chunk; });
      req.on('end', async () => {
        try {
          const data = JSON.parse(body || '{}');
          const reqItem = requests.find(r => r.id === data.id);
          if (!reqItem) {
            res.writeHead(404, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ success: false, message: 'Request not found' }));
            return;
          }
          reqItem.status = 'APPROVED';
          reqItem.approvedBy = data.approvedBy || 'Director (Web App)';
          reqItem.approvedAt = new Date().toLocaleString('en-US');
          saveRequests();

          // Notify Staff via Telegram
          await sendMessage(reqItem.chatId, 
            `🎉 <b>[សេចក្តីជូនដំណឹង: សំណើដកសម្ភារៈត្រូវបានអនុម័ត!]</b>\n` +
            `ពាក្យស្នើសុំលេខ <code>${reqItem.id}</code> សម្រាប់ <b>${reqItem.itemName}</b> ចំនួន <b>${reqItem.qty} ${reqItem.unit}</b> ត្រូវបានអនុម័តដោយ <b>${reqItem.approvedBy}</b>។\n` +
            `👉 លោកអ្នកអាចទៅទទួលសម្ភារៈពីអ្នកកាន់ស្តុកបាន!`
          );

          res.writeHead(200, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ success: true, request: reqItem }));
        } catch (e) {
          res.writeHead(500, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ success: false, error: e.message }));
        }
      });
      return;
    }

    res.writeHead(404, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ error: 'Endpoint not found' }));
  });

  httpServer.listen(HTTP_PORT, () => {
    console.log(`🌐 ស្ពានទិន្នន័យ Live Sync API កំពុងដំណើរការលើ http://localhost:${HTTP_PORT}`);
    console.log(`   👉 GET http://localhost:${HTTP_PORT}/api/requests (Auto-Sync ជាមួយ Web App)`);
  });

  httpServer.on('error', (err) => {
    if (err.code === 'EADDRINUSE') {
      console.warn(`⚠️ Port ${HTTP_PORT} កំពុងជាប់រវល់ នឹងប្តូរទៅសាកល្បង Port ${HTTP_PORT + 1}`);
      httpServer.listen(HTTP_PORT + 1);
    } else {
      console.error('HTTP Server error:', err.message);
    }
  });
}

// 12. SERVICE STARTUP
async function start() {
  console.log('================================================================');
  console.log('🚀 NEW VISION INVENTORY - 3-TIER TELEGRAM BOT SERVICE STARTING');
  console.log('================================================================');

  if (!config.botToken || config.botToken === 'YOUR_TELEGRAM_BOT_TOKEN_HERE') {
    console.log('\n⚠️  មិនទាន់បានកំណត់ Bot Token នៅឡើយទេ!');
    console.log('👉 សូមបង្កើតឯកសារ telegram_bot_config.json ឬកំណត់ក្នុង process.env.TELEGRAM_BOT_TOKEN');
    console.log('👉 ឧទាហរណ៍ក្នុង telegram_bot_config.json:');
    console.log(JSON.stringify({
      botToken: '7123456789:AAHxxxxxxxxxxxxxxxxxxxxxxxxxxxx',
      stockKeeperChatId: '123456789',
      directorChatId: '987654321',
      schoolName: 'សាលារៀន ញូវវីសិន (New Vision School)'
    }, null, 2));
    console.log('================================================================\n');
    return;
  }

  // Start HTTP Sync Server
  startHttpApi();

  try {
    const me = await apiCall('getMe', {});
    console.log(`✅ បានភ្ជាប់ជាមួយ Telegram Bot: @${me.username} (${me.first_name}) ជោគជ័យ!`);
    console.log(`👨‍💼 Stock Keeper Chat ID: ${config.stockKeeperChatId || '(មិនទាន់កំណត់)'}`);
    console.log(`👑 Director Chat ID:     ${config.directorChatId || '(មិនទាន់កំណត់)'}`);
    console.log('📡 កំពុងបើក Long-polling ទទួលសំណើពីបុគ្គលិក... (ចុច Ctrl+C ដើម្បីបញ្ឈប់)\n');
    pollUpdates();
  } catch (err) {
    console.error('❌ មិនអាចភ្ជាប់ទៅកាន់ Telegram បានទេ:', err.message);
  }
}

start();

module.exports = {
  CATALOG,
  config,
  dispatchToStockKeeper,
  dispatchToDirector,
  sendMessage
};
