-- =========================================================================
-- សាលារៀន ញូវវីសិន (NEW VISION SCHOOL) - INVENTORY MANAGEMENT SYSTEM V2.0
-- SUPABASE POSTGRESQL PRODUCTION DATABASE SCHEMA & INITIAL SEED
-- =========================================================================
-- ការណែនាំក្នុងការដំឡើង (Quick Setup):
-- ១. ចូលទៅកាន់គណនី Supabase របស់អ្នក (https://supabase.com)
-- ២. ជ្រើសរើស Project របស់អ្នក -> ចុចលើ "SQL Editor" នៅខាងឆ្វេងដៃ
-- ៣. ចម្លង (Copy) កូដ SQL ទាំងអស់ខាងក្រោមនេះ រួចបិទភ្ជាប់ (Paste)
-- ៤. ចុចប៊ូតុង "Run" (ពណ៌បៃតង) ដើម្បីបង្កើតតារាង និងរៀបចំ Realtime ដោយស្វ័យប្រវត្តិ!
-- =========================================================================

-- ១. បើក Extension UUID
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ២. តារាងសាខាសាលារៀន (Campuses / Branches)
CREATE TABLE IF NOT EXISTS branches (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    location TEXT,
    phone TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- ៣. តារាងប្រភេទសម្ភារៈ (Categories)
CREATE TABLE IF NOT EXISTS categories (
    id SERIAL PRIMARY KEY,
    name TEXT UNIQUE NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- ៤. តារាងផ្នែក / ដេប៉ាតឺម៉ង់ (Departments)
CREATE TABLE IF NOT EXISTS departments (
    id SERIAL PRIMARY KEY,
    name TEXT UNIQUE NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- ៥. តារាងបុគ្គលិកសាលា (Staff Directory)
CREATE TABLE IF NOT EXISTS staff (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    dept TEXT,
    role TEXT,
    phone TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- ៦. តារាងបញ្ជីស្តុកមេ (Inventory Items)
CREATE TABLE IF NOT EXISTS inventory_items (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    category TEXT,
    unit TEXT DEFAULT 'គ្រឿង',
    initial_stock NUMERIC DEFAULT 0,
    min_stock NUMERIC DEFAULT 5,
    unit_price NUMERIC DEFAULT 0.00,
    branch_id TEXT DEFAULT 'BR-01',
    branch_name TEXT DEFAULT 'សាខាទី ១ (ច្បារអំពៅ - ទីតាំងធំ)',
    building TEXT,
    floor TEXT,
    room TEXT,
    shelf TEXT,
    note TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- បង្កើត VIEW ឬ Synonyms សម្រាប់ភាពឆបគ្នា
CREATE OR REPLACE VIEW items AS SELECT * FROM inventory_items;

-- ៧. តារាងកត់ត្រាការនាំចូលស្តុក (Stock In / Purchases)
CREATE TABLE IF NOT EXISTS stock_in (
    id TEXT PRIMARY KEY,
    date DATE NOT NULL DEFAULT CURRENT_DATE,
    item_id TEXT REFERENCES inventory_items(id) ON DELETE SET NULL,
    item_name TEXT NOT NULL,
    qty NUMERIC NOT NULL CHECK (qty > 0),
    unit_price NUMERIC DEFAULT 0.00,
    total_cost NUMERIC GENERATED ALWAYS AS (qty * unit_price) STORED,
    branch_id TEXT DEFAULT 'BR-01',
    supplier TEXT,
    invoice TEXT,
    receiver TEXT,
    created_by TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- ៨. តារាងកត់ត្រាស្នើសុំ និងចេញស្តុក (Stock Out / Requests & Approvals)
CREATE TABLE IF NOT EXISTS stock_out (
    id TEXT PRIMARY KEY,
    date DATE NOT NULL DEFAULT CURRENT_DATE,
    item_id TEXT REFERENCES inventory_items(id) ON DELETE SET NULL,
    item_name TEXT NOT NULL,
    qty NUMERIC NOT NULL CHECK (qty > 0),
    branch_id TEXT DEFAULT 'BR-01',
    branch_name TEXT DEFAULT 'សាខាទី ១ (ច្បារអំពៅ - ទីតាំងធំ)',
    purpose TEXT,
    req_name TEXT NOT NULL,
    req_dept TEXT,
    appr_id TEXT,
    appr_name TEXT,
    appr_role TEXT,
    appr_date DATE,
    status TEXT DEFAULT 'រង់ចាំអនុម័ត',
    source TEXT DEFAULT 'WEB',
    chat_id NUMERIC,
    created_by TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- ៩. តារាងកត់ត្រាប្រវត្តិសវនកម្មប្រព័ន្ធ (Audit Logs)
CREATE TABLE IF NOT EXISTS audit_logs (
    id TEXT PRIMARY KEY,
    timestamp TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    user_id TEXT,
    user_name TEXT,
    user_role TEXT,
    action TEXT,
    target_type TEXT,
    target_name TEXT,
    details TEXT
);

-- ១០. តារាងគណនីអ្នកប្រើប្រាស់ និងសិទ្ធិ (App Users)
CREATE TABLE IF NOT EXISTS app_users (
    id TEXT PRIMARY KEY,
    username TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    name TEXT NOT NULL,
    role TEXT NOT NULL,
    role_kh TEXT,
    permissions JSONB DEFAULT '{"can_create": true, "can_edit": true, "can_delete": false}',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- =========================================================================
-- បញ្ចូលទិន្នន័យគំរូដំបូង (Initial Seed Data)
-- =========================================================================

-- សាខា
INSERT INTO branches (id, name, location, phone) VALUES
('BR-01', 'សាខាទី ១ (ច្បារអំពៅ - ទីតាំងធំ)', 'ខណ្ឌច្បារអំពៅ រាជធានីភ្នំពេញ', '023 888 991'),
('BR-02', 'សាខាទី ២ (សាខាថ្មី)', 'ខណ្ឌទួលគោក រាជធានីភ្នំពេញ', '023 888 992')
ON CONFLICT (id) DO NOTHING;

-- ប្រភេទសម្ភារៈ
INSERT INTO categories (name) VALUES
('ឧបករណ៍បច្ចេកវិទ្យា & IT'),
('សម្ភារៈការិយាល័យ & រដ្ឋបាល'),
('សៀវភៅ & ឯកសារសិក្សា'),
('សម្ភារៈបន្ទប់ពិសោធន៍ (Lab)'),
('គ្រឿងសង្ហារិម & តុ កៅអី'),
('សម្ភារៈកីឡា & អប់រំកាយ'),
('សម្ភារៈអគ្គិសនី & ទឹក'),
('សម្ភារៈអនាម័យ & ថែទាំទូទៅ')
ON CONFLICT (name) DO NOTHING;

-- ដេប៉ាតឺម៉ង់
INSERT INTO departments (name) VALUES
('ការិយាល័យនាយក (Director Office)'),
('ការិយាល័យរដ្ឋបាល & បុគ្គលិក'),
('គណនេយ្យ & ហិរញ្ញវត្ថុ'),
('ផ្នែកបច្ចេកវិទ្យា & IT'),
('ផ្នែកបឋមសិក្សា (Primary)'),
('ផ្នែកអនុវិទ្យាល័យ (Secondary)'),
('ផ្នែកវិទ្យាល័យ (High School)'),
('បណ្ណាល័យ (Library)'),
('ផ្នែកថែទាំ & សន្តិសុខ')
ON CONFLICT (name) DO NOTHING;

-- បុគ្គលិក
INSERT INTO staff (id, name, dept, role, phone) VALUES
('NV-DIR-001', 'លោក ហ៊ុយ ចាន់ពិសី', 'ការិយាល័យនាយក (Director Office)', 'នាយកសាលា (Director)', '012 345 678'),
('NV-DIR-002', 'HUY CHANPISEY', 'ការិយាល័យនាយក (Director Office)', 'នាយកសាលា (Director)', '@chan_pisey'),
('NV-STF-001', 'លោក សុខ ចាន់រិទ្ធ', 'ផ្នែកបច្ចេកវិទ្យា & IT', 'អ្នកគ្រប់គ្រងស្តុក (Stock Keeper)', '011 223 344'),
('NV-TEA-001', 'អ្នកគ្រូ ស៊ឹម ម៉ាលី', 'ផ្នែកវិទ្យាល័យ (High School)', 'គ្រូបង្រៀនគណិតវិទ្យា', '089 998 877'),
('NV-TEA-002', 'លោក គង់ វណ្ណា', 'ផ្នែកបឋមសិក្សា (Primary)', 'គ្រូបង្រៀនថ្នាក់ទី ៥', '010 554 433')
ON CONFLICT (id) DO NOTHING;

-- សម្ភារៈដំបូង
INSERT INTO inventory_items (id, name, category, unit, initial_stock, min_stock, unit_price, branch_id, branch_name, building, floor, room, shelf, note) VALUES
('NV-IT-001', 'កុំព្យូទ័រយួរដៃ Dell Latitude 3420', 'ឧបករណ៍បច្ចេកវិទ្យា & IT', 'គ្រឿង', 35, 5, 580.00, 'BR-01', 'សាខាទី ១ (ច្បារអំពៅ - ទីតាំងធំ)', 'អាគារ B (អនុវិទ្យាល័យ)', 'ជាន់ទី ២', 'បន្ទប់កុំព្យូទ័រ Lab 01', 'ទូ IT-01', 'Core i5, RAM 16GB, SSD 512GB សម្រាប់សិស្សរៀន Coding'),
('NV-IT-002', 'ម៉ាស៊ីនបញ្ចាំងស្លាយ Epson EB-X06 Projector', 'ឧបករណ៍បច្ចេកវិទ្យា & IT', 'គ្រឿង', 8, 2, 395.00, 'BR-01', 'សាខាទី ១ (ច្បារអំពៅ - ទីតាំងធំ)', 'អាគារ A (បឋម)', 'ជាន់ទី ១', 'សាលប្រជុំ & សិក្ខាសាលា', 'ធ្នើរ A-01', 'Projector HDMI ភ្ជាប់ក្នុងសាលប្រជុំ'),
('NV-OFF-001', 'ក្រដាសហ្វូតូ Double A A4 (80gsm)', 'សម្ភារៈការិយាល័យ & រដ្ឋបាល', 'កេស', 60, 15, 24.50, 'BR-01', 'សាខាទី ១ (ច្បារអំពៅ - ទីតាំងធំ)', 'អាគាររដ្ឋបាល', 'ជាន់ផ្ទាល់ដី', 'ឃ្លាំងស្តុករដ្ឋបាល', 'ធ្នើរឈើ ០១', '១ កេស មាន ៥ រីម សម្រាប់បោះពុម្ពវិញ្ញាសា'),
('NV-LAB-001', 'មីក្រូទស្សន៍ជីវវិទ្យា Compound Microscope', 'សម្ភារៈបន្ទប់ពិសោធន៍ (Lab)', 'គ្រឿង', 12, 3, 165.00, 'BR-02', 'សាខាទី ២ (សាខាថ្មី)', 'អាគារវិទ្យាសាស្ត្រ', 'ជាន់ទី ២', 'បន្ទប់ពិសោធន៍ជីវវិទ្យា', 'ទូកញ្ចក់ LAB-02', 'ការពង្រីក 1000x សម្រាប់ពិសោធន៍វិទ្យាល័យ'),
('NV-FUR-001', 'តុ និងកៅអីសិស្សឈើប្រណិត (Single Desk Set)', 'គ្រឿងសង្ហារិម & តុ កៅអី', 'ឈុត', 45, 5, 38.00, 'BR-02', 'សាខាទី ២ (សាខាថ្មី)', 'អាគារសិក្សាថ្មី', 'ជាន់ទី ១', 'ថ្នាក់ទី 10A', 'ក្នុងថ្នាក់', 'ឈុតតុដែកស្វិតបំពាក់ក្តារបន្ទះគុណភាពខ្ពស់')
ON CONFLICT (id) DO NOTHING;

-- គណនីចូលប្រើប្រព័ន្ធ
INSERT INTO app_users (id, username, password, name, role, role_kh, permissions) VALUES
('usr_director', 'director', 'director123', 'លោក ហ៊ុយ ចាន់ពិសី', 'director', 'នាយកសាលា (Director)', '{"can_create": true, "can_edit": true, "can_delete": true}'),
('usr_stock', 'stock', 'stock123', 'លោក សុខ ចាន់រិទ្ធ', 'stock_staff', 'អ្នកកាន់ស្តុក (Stock Staff)', '{"can_create": true, "can_edit": true, "can_delete": false}'),
('usr_staff', 'staff', 'staff123', 'អ្នកគ្រូ ស៊ឹម ម៉ាលី', 'teacher', 'បុគ្គលិកទូទៅ (Staff)', '{"can_create": true, "can_edit": false, "can_delete": false}')
ON CONFLICT (username) DO NOTHING;

-- បញ្ចូលសំណើ Telegram ដំបូង
INSERT INTO stock_out (id, date, item_id, item_name, qty, branch_id, branch_name, purpose, req_name, req_dept, appr_id, appr_name, appr_role, status, source, chat_id)
VALUES ('REQ-20261027-7603', CURRENT_DATE, 'NV-IT-001', 'កុំព្យូទ័រយួរដៃ Dell Latitude 3420', 1, 'BR-01', 'សាខាទី ១ (ច្បារអំពៅ - ទីតាំងធំ)', 'យកទៅបង្រៀនសិស្សក្នុងថ្នាក់', 'HUY CHANPISEY', 'ការិយាល័យនាយក (Director Office)', 'director', 'HUY CHANPISEY (លោកនាយកសាលា)', 'នាយកសាលា (Director)', 'បានអនុម័ត', 'TELEGRAM_BOT', 242585419)
ON CONFLICT (id) DO NOTHING;

-- =========================================================================
-- បើក ROW LEVEL SECURITY (RLS) & បង្កើត POLICIES សម្រាប់ ANON / PUBLIC
-- =========================================================================
ALTER TABLE branches ENABLE ROW LEVEL SECURITY;
ALTER TABLE categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE departments ENABLE ROW LEVEL SECURITY;
ALTER TABLE staff ENABLE ROW LEVEL SECURITY;
ALTER TABLE inventory_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE stock_in ENABLE ROW LEVEL SECURITY;
ALTER TABLE stock_out ENABLE ROW LEVEL SECURITY;
ALTER TABLE audit_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE app_users ENABLE ROW LEVEL SECURITY;

-- អនុញ្ញាតឱ្យ Web Client (anon key) អាន និងកែប្រែបានពេញលេញ
CREATE POLICY "Allow Public All Branches" ON branches FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow Public All Categories" ON categories FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow Public All Departments" ON departments FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow Public All Staff" ON staff FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow Public All Items" ON inventory_items FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow Public All Stock In" ON stock_in FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow Public All Stock Out" ON stock_out FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow Public All Audit Logs" ON audit_logs FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow Public Read Users" ON app_users FOR SELECT USING (true);
CREATE POLICY "Allow Public Write Users" ON app_users FOR ALL USING (true) WITH CHECK (true);

-- =========================================================================
-- បើក SUPABASE REALTIME WEBSOCKETS (សម្រាប់ការ Sync ភ្លាមៗក្នុងពេលតែមួយ)
-- =========================================================================
ALTER PUBLICATION supabase_realtime ADD TABLE inventory_items;
ALTER PUBLICATION supabase_realtime ADD TABLE stock_out;
ALTER PUBLICATION supabase_realtime ADD TABLE stock_in;
ALTER PUBLICATION supabase_realtime ADD TABLE staff;
ALTER PUBLICATION supabase_realtime ADD TABLE audit_logs;

SELECT '🎉 NEW VISION SCHOOL INVENTORY V2.0 SCHEMA & REALTIME SETUP COMPLETE!' as status;
