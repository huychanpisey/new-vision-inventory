# 🏫 សាលារៀន ញូវវីសិន (New Vision School) - Inventory & Asset Management System V2.0

ប្រព័ន្ធគ្រប់គ្រងសារពើភ័ណ្ឌ ទ្រព្យសម្បត្តិ និងស្តុកសម្ភារៈសាលារៀន ញូវវីសិន (New Vision School) កំណែទម្រង់ V2.0 Enterprise Cloud Release។ ប្រព័ន្ធនេះគាំទ្រការតភ្ជាប់ជាមួយ **Supabase Cloud PostgreSQL Database**, ការ Deploy លើ **Vercel**, និងការស្នើសុំ/អនុម័តសម្ភារៈតាម **Telegram Bot (3-Tier Multi-Role Hub)**។

---

## 🌟 លក្ខណៈពិសេសចម្បងៗ (Key Features)

1. **Dashboard & Analytics (KPIs ពេលវេលាជាក់ស្តែង)**៖
   - បង្ហាញតម្លៃស្តុកសរុប ($), ចំនួនមុខទំនិញ, ស្តុកជិតអស់, និងសំណើរង់ចាំការអនុម័ត។
   - ក្រាហ្វិកចំណាត់ថ្នាក់តាមប្រភេទសម្ភារៈ និងចលនាស្តុកប្រចាំខែ។

2. **3-Tier Interactive Telegram Bot Hub**៖
   - **បុគ្គលិក / គ្រូបង្រៀន**៖ ស្នើសុំដកសម្ភារៈតាមទូរស័ព្ទដៃ ដោយមិនបាច់ស្គាល់ Chat ID (Auto Detection)។
   - **អ្នកកាន់ស្តុក**៖ ពិនិត្យស្តុកជាក់ស្តែងក្នុងឃ្លាំង រួចចុចបញ្ជាក់ & បញ្ជូនបន្ត។
   - **នាយកសាលា**៖ ពិនិត្យ និងចុច `[✅ អនុម័ត]` ឬ `[❌ បដិសេធ]` ពីលើ Telegram ផ្ទាល់។
   - **គាំទ្រ Telegram Group**៖ អាច Add Bot ចូលក្នុង Group គណៈកម្មការសាលា (`/set_group`) ដើម្បីអនុម័តរួមគ្នាក្នុង Group តែមួយ។

3. **Multi-Campus Context & Filter**៖
   - ប្តូរសាខាភ្លាមៗ (សាខាទី ១ ច្បារអំពៅ, សាខាទី ២ ទួលគោក ឬមើលគ្រប់សាខា) ជាមួយពណ៌ច្បាស់ត្រជាក់ភ្នែក។

4. **Staff Directory & Custody Management (បុគ្គលិក & កាន់កាប់)**៖
   - បង្ហាញបញ្ជីបុគ្គលិកជា List View ទំនើប។
   - ចុចលើបុគ្គលិកណាម្នាក់ ដើម្បីមើលប្រវត្តិស្នើសុំ សម្ភារៈដែលគាត់កំពុងកាន់កាប់ជាក់ស្តែង និងចំនួនដងដែលបានអនុម័ត/បដិសេធ។

5. **Role-Based Access Control (RBAC) & Audit Trail**៖
   - គណនីនាយកសាលា (Director), អ្នកកាន់ស្តុក (Stock Staff), និងបុគ្គលិកទូទៅ (Staff)។
   - កត់ត្រារាល់សកម្មភាពបង្កើត កែប្រែ ឬលុបទិន្នន័យចូលក្នុង System Audit Trail ស្វ័យប្រវត្តិ។

6. **Spotlight Search & Barcode Scanner**៖
   - ចុច `Ctrl + K` ដើម្បីបើកផ្ទាំងស្វែងរករហ័ស ឬស្កេន Barcode / QR Code។

7. **Universal Reports & Export**៖
   - បង្កើតរបាយការណ៍ផ្លូវការ (ប្រចាំសប្តាហ៍, ខែ, ត្រីមាស, ឆមាស, ឆ្នាំ)។
   - ទាញយកជា Excel (`.xlsx`) ឬបោះពុម្ពជា PDF ជាមួយក្បាលសំបុត្រក្រសួងអប់រំ និងប្លុកហត្ថលេខា ៣ ភាគី។

---

## 🚀 ការដំឡើង និងដាក់ឱ្យដំណើរការ (Deployment)

សូមមើលសៀវភៅណែនាំពេញលេញក្នុងឯកសារ [DEPLOY_OFFICIAL_PRODUCTION_GUIDE.md](DEPLOY_OFFICIAL_PRODUCTION_GUIDE.md)។

### ១. Supabase Setup
1. ចូលគណនី Supabase -> បើក **SQL Editor**។
2. Copy កូដពី [supabase_schema.sql](supabase_schema.sql) រួចចុច **Run**។
3. ចម្លង `Project URL` និង `anon key`។

### ២. Vercel Setup
1. ភ្ជាប់ GitHub Repository នេះទៅកាន់ **Vercel**។
2. ចុច **Deploy** (ដំណើរការលើ HTTPS ស្វ័យប្រវត្តិ)។
3. បើក Settings ក្នុង Web App រួចបញ្ចូល Supabase URL & Key។

### ៣. Telegram Bot Setup
1. បើកដំណើរការ Bot ដោយផ្ទាល់តាមរយៈ `node telegram_bot_service.js` ឬនៅលើ **Render.com** (Free 24/7)។
2. កំណត់ Bot Token ក្នុង `telegram_bot_config.json` ឬ Environment Variables។

---

## 📁 រចនាសម្ព័ន្ធឯកសារ (Project Structure)

```text
├── index.html                          # ផ្ទាំង Web App Dashboard V2.0 ផ្លូវការ
├── supabase_schema.sql                 # PostgreSQL Schema & Seed Data សម្រាប់ Supabase
├── telegram_bot_service.js             # 3-Tier Telegram Bot Engine & Live Sync Bridge
├── telegram_bot_config.json            # ការកំណត់ Bot Token និង Chat IDs
├── package.json                        # Node.js project manifest
├── vercel.json                         # ការកំណត់ Vercel Deployment & Rewrites
├── DEPLOY_OFFICIAL_PRODUCTION_GUIDE.md # សៀវភៅណែនាំដំឡើងផលិតកម្មលម្អិត
├── school_logo.png                     # និមិត្តសញ្ញាសាលារៀន ញូវវីសិន
├── moeys_logo.svg                      # និមិត្តសញ្ញាក្រសួងអប់រំ យុវជន និងកីឡា
└── assets/                             # បណ្ណាល័យជំនួយ (SheetJS, Mammoth, Icons)
```

---

© 2026 សាលារៀន ញូវវីសិន (New Vision School). រក្សាសិទ្ធិគ្រប់យ៉ាង។
