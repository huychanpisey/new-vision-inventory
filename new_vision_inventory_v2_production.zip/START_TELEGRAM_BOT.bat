@echo off
setlocal enabledelayedexpansion
title New Vision Inventory - Telegram Bot Service
cd /d "%~dp0"

echo =======================================================================
echo   NEW VISION SCHOOL - TELEGRAM BOT SERVICE V2.0
echo =======================================================================
echo.

rem 1. Check Antigravity agy-node in AppData
if exist "%APPDATA%\Antigravity\bin\agy-node.cmd" (
    call "%APPDATA%\Antigravity\bin\agy-node.cmd" telegram_bot_service.js
    goto :end
)

rem 2. Check Antigravity executable directly
if exist "%LOCALAPPDATA%\Programs\antigravity\Antigravity.exe" (
    set ELECTRON_RUN_AS_NODE=1
    "%LOCALAPPDATA%\Programs\antigravity\Antigravity.exe" telegram_bot_service.js
    goto :end
)

rem 3. Check system Node.js in PATH
where node >nul 2>nul
if %errorlevel% equ 0 (
    node telegram_bot_service.js
    goto :end
)

rem 4. Check Program Files node.exe
if exist "%ProgramFiles%\nodejs\node.exe" (
    "%ProgramFiles%\nodejs\node.exe" telegram_bot_service.js
    goto :end
)

echo [ERROR] Could not find Node.js or agy-node runtime.
echo Please make sure Antigravity or Node.js is installed.

:end
echo.
pause
