# 🚀 សៀវភៅណែនាំដំឡើងប្រព័ន្ធប្រើប្រាស់ផ្លូវការ (OFFICIAL PRODUCTION DEPLOYMENT GUIDE)
## សាលារៀន ញូវវីសិន (New Vision School Inventory System V2.0)

សៀវភៅណែនាំនេះត្រូវបានរៀបចំឡើងជាពិសេស ដើម្បីណែនាំលោកក្នុងការដាក់ឱ្យដំណើរការប្រព័ន្ធនេះជាផ្លូវការ (Official Production) ដោយប្រើប្រាស់គណនី Free ទាំង ៣ ដែលលោកមានរួចជាស្រេច៖
1. **Supabase** (Cloud PostgreSQL Database & Real-Time Sync)
2. **Vercel** (Cloud Web App Hosting - HTTPS & Global CDN)
3. **GitHub** (Source Control Repository)
4. **Render.com** (ដំណើរការ Telegram Bot ២៤/៧ ដោយឥតគិតថ្លៃ)

---

## 📋 ជំហានទី ១៖ ដំឡើង Cloud Database លើ Supabase (ចំណាយពេល ២ នាទី)

1. បើក Browser ចូលទៅកាន់គណនី **[Supabase](https://supabase.com)**
2. បង្កើត Project ថ្មី ឬជ្រើសរើស Project ដែលមានស្រាប់
3. នៅលើ Menu ខាងឆ្វេងដៃ ចុចលើរូប **SQL Editor** (រូបតំណាង `>_`)
4. បើកឯកសារ `supabase_schema.sql` ក្នុង folder គម្រោងនេះ ចម្លង (Copy) កូដ SQL ទាំងអស់
5. បិទភ្ជាប់ (Paste) ចូលក្នុង SQL Editor របស់ Supabase
6. ចុចប៊ូតុង **Run** (ពណ៌បៃតងនៅខាងស្តាំដៃ)
   - *ប្រព័ន្ធនឹងបង្កើតតារាងទាំង ៨ ព្រមទាំងបើក Realtime WebSockets ជូនដោយស្វ័យប្រវត្តិ!*
7. យកព័ត៌មានភ្ជាប់ (API Keys)៖
   - ចុចលើរូប **Project Settings** (រូបកង់ធ្មេញនៅខាងឆ្វេងខាងក្រោម) -> ជ្រើសរើស **API**
   - ចម្លងទុកនូវ៖
     - **Project URL** (ឧទាហរណ៍ `https://abcdefghijklmn.supabase.co`)
     - **anon / public key** (កូដវែង `eyJhbGciOi...`)

---

## 📋 ជំហានទី ២៖ ផ្ទុកកូដឡើង GitHub (Upload to GitHub)

1. ចូលទៅកាន់គណនី **[GitHub](https://github.com)**
2. បង្កើត Repository ថ្មីមួយ (ចុច **New**) ដាក់ឈ្មោះថា `new-vision-inventory` (ជ្រើសរើសជា **Public** ឬ **Private** តាមការចង់បាន)
3. ផ្ទុកឯកសារ (Upload files) ក្នុង folder `d:\projec_inventory` ទាំងអស់ចូលក្នុង Repository នោះ ជាពិសេស៖
   - `index.html` (ផ្ទាំងគ្រប់គ្រងប្រព័ន្ធ)
   - `school_logo.png` (រូប Logo សាលា)
   - `vercel.json` (ការកំណត់ Routing)
   - `telegram_bot_service.js` (កូដដំណើរការ Bot)
   - `telegram_bot_config.json`
   - `supabase_schema.sql`
   - `assets/` (ប្រសិនបើមាន)
4. ចុច **Commit changes** រួចជាស្រេច។

---

## 📋 ជំហានទី ៣៖ Deploy ផ្ទាំង Web App ឡើង Vercel (ចំណាយពេល ១ នាទី)

1. ចូលទៅកាន់គណនី **[Vercel](https://vercel.com)**
2. ចុចប៊ូតុង **Add New...** -> ជ្រើសរើស **Project**
3. ស្វែងរក Repository `new-vision-inventory` ពី GitHub របស់លោក រួចចុច **Import**
4. ត្រង់កន្លែង Settings មិនចាំបាច់កែប្រែអ្វីទេ ចុចប៊ូតុង **Deploy** ភ្លាម
5. រង់ចាំប្រហែល ២០ ទៅ ៣០ វិនាទី លោកនឹងទទួលបាន Link គេហទំព័រផ្លូវការ (ឧទាហរណ៍ `https://new-vision-inventory.vercel.app`)!
6. បើកចូលគេហទំព័រនោះ -> ចូលទៅកាន់ Menu **ការកំណត់ (Settings)** -> ត្រង់ប្រអប់ **Supabase Cloud Database**៖
   - បញ្ចូល **Supabase URL** និង **Anon Key** ដែលបានចម្លងពីជំហានទី ១
   - ចុច **រក្សាទុក** នោះប្រព័ន្ធនឹងភ្ជាប់ទៅកាន់ Cloud Database ជោគជ័យ ១០០%!

---

## 📋 ជំហានទី ៤៖ ដាក់ឱ្យ Telegram Bot ដំណើរការ ២៤/៧ លើ Render.com (Free)

ដើម្បីឱ្យ Telegram Bot ដំណើរការឆ្លើយតបបុគ្គលិក ២៤ម៉ោងលើ២៤ម៉ោង ដោយមិនបាច់បើកកុំព្យូទ័រ Laptop របស់លោកចោល៖

1. ចូលទៅកាន់ **[Render.com](https://render.com)** (អាច Sign in ដោយប្រើគណនី GitHub របស់លោក)
2. ចុចប៊ូតុង **New +** នៅខាងលើស្តាំ -> ជ្រើសរើស **Web Service** (ឬ Background Worker)
3. ជ្រើសរើស Repository `new-vision-inventory`
4. បំពេញព័ត៌មានងាយៗ៖
   - **Name**: `new-vision-telegram-bot`
   - **Runtime**: `Node`
   - **Build Command**: (ទុកទទេ ឬដាក់ `npm install`)
   - **Start Command**: `node telegram_bot_service.js`
   - **Instance Type**: ជ្រើសរើស `Free` ($0/month)
5. ត្រង់ចំណុច **Environment Variables** (ចុច Add Environment Variable)៖
   - `TELEGRAM_BOT_TOKEN`: `8934461079:AAFEYyaAM66y69s5Jqjs2oVOhFoM_QCNzvU`
   - `TELEGRAM_DIRECTOR_CHAT_ID`: `242585419`
   - `TELEGRAM_STOCK_CHAT_ID`: `242585419`
   - `SUPABASE_URL`: (Supabase URL របស់លោក)
   - `SUPABASE_KEY`: (Supabase Anon Key របស់លោក)
6. ចុច **Create Web Service**!
   - *រួចរាល់! Render នឹងដំណើរការ Bot លើ Cloud រហូត ២៤/៧ ដោយមិនគិតថ្លៃសូម្បីតែមួយសេន!*

---

## 🏆 ដំណើរការជាក់ស្តែងពេលដាក់ប្រើប្រាស់ផ្លូវការ (End-to-End Workflow)

1. **គ្រូបង្រៀន / បុគ្គលិក**៖ 
   - ចូល Telegram Bot ចុច `/request` ជ្រើសរើសសម្ភារៈ និងចំនួន រួចផ្ញើសំណើ។
2. **អ្នកកាន់ស្តុក**៖ 
   - ទទួលបានសារក្នុង Telegram ពិនិត្យឃើញសម្ភារៈក្នុងឃ្លាំង រួចចុច `📦 បញ្ជាក់ & បញ្ជូនបន្តទៅនាយក`។
3. **លោកនាយកសាលា**៖ 
   - ទទួលបានសារលើទូរស័ព្ទដៃ រួចចុច `✅ អនុម័ត (Approve)`។
4. **ប្រព័ន្ធស្វ័យប្រវត្តិតាម Cloud**៖ 
   - Bot សរសេរទិន្នន័យចូល Supabase Cloud ភ្លាមៗ។
   - Web App លើ Vercel ទទួលបាន Realtime Event ធ្វើបច្ចុប្បន្នភាព Dashboard, កាត់ស្តុក, បង្ហាញក្នុងតារាង Stock Out និងកត់ចូលប្រវត្តិបុគ្គលិកក្នុងរយៈពេលត្រឹម **0.1 វិនាទី**!
